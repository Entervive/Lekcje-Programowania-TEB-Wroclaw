<?php
	$host="localhost"; // Nazwa hosta
	$user="root"; // Nazwa uzytkownika mysql
	$password=""; // Haslo do bazy
	$database="ksiegarnia"; // Nazwa bazy
	$table1="klienci"; //Nazwa tabeli
	$table2="ksiazki"; //Nazwa tabeli
	$table3="zamowienia"; //Nazwa tabeli
?>
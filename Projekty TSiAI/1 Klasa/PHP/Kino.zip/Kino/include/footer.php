<?php
    echo '&copf; Aleksander Staszków' . "<br>" . date("d-M-Y"); 
?>
<?php
    echo '<h1>Kino "Tytan"</h1>';
    echo '<p>Twoje kino doznań</p>';
    echo '<a href="index.php">Strona Główna</a>';
    echo '<a href="dodajtowary.php">Dodaj Towar</a>';
?>